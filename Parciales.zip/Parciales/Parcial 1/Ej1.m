%% Se mide aceleraciones que se componen de dos componentes sinusoidales de
%% 1 y 2 Hz. Durante la medici�n hay fuerte ruido de l�nea que contamina la 
%% se�al con otra componente de 60 Hz. La aceleraci�n medida ser� sub-
%% muestreada de 300 Hz a 50 Hz (decimando cada 6), con lo cual la 
%% componente de ruido de l�nea deber�a desaparecer (f_N=fs/2=25 < 60). 
%% Sin embargo, a�n est� presente.
%% Arregle la secci�n Filtering de manera tal que se maximice la SNR. Note
%% que la definici�n de SNR utilizada para evaluar su soluci�n tiene en
%% cueta la fase.

clc
close all
clear

ti = 0 % s
tf = 2 % s
fs = 300 % Hz
t = ti:1/fs:tf;

f_signal_1 = 1 % Hz
f_signal_2 = 2 % Hz
f_noise = 60 % Hz
actual_accel = sin(2*pi*f_signal_1*t) +  sin(2*pi*f_signal_2*t);
noise = 2*sin(2*pi*f_noise*t);
measured_accel = actual_accel + noise;


%% Filtering
b = 1;
a = 1;
filtered_measured_accel = filter(b, a, measured_accel);

figure
bode(filt(b, a, 1/fs))


%% Subsampling
fs_new = 50 % Hz
subsampled_filtered_measured_accel = filtered_measured_accel(1:round(fs/fs_new):end);
subsampled_t = t(1:round(fs/fs_new):end);


X = abs(fft(measured_accel));
X_filt = abs(fft(filtered_measured_accel));
figure
hold on
plot(linspace(0, fs/2, round(length(X)/2)), X(1:round(length(X)/2)), 'linewidth', 2);
plot(linspace(0, fs/2, round(length(X_filt)/2)), X_filt(1:round(length(X_filt)/2)), 'linewidth', 2);
legend('measured accel', 'filtered accel')
xlabel('f (Hz)')


figure
hold on
plot(t, [measured_accel; actual_accel], 'linewidth', 2)
plot(subsampled_t, subsampled_filtered_measured_accel, 'linewidth', 2)
xlabel('t (s)')
legend('measured accel', 'actual accel', 'subsampled measured accel')


%% Evaluation
subsampled_actual_accel = actual_accel(1:round(fs/fs_new):end);
SNR = 20*log10(rms(subsampled_actual_accel)/rms(subsampled_filtered_measured_accel - subsampled_actual_accel))

if SNR < 10
    disp(['Nota Ej 1 = 2'])
elseif SNR < 13
    disp(['Nota Ej 1 = 3'])
elseif SNR < 16
    disp(['Nota Ej 1 = 4'])
elseif SNR < 19
    disp(['Nota Ej 1 = 5'])
elseif SNR < 22
    disp(['Nota Ej 1 = 6'])
else
    disp(['Nota Ej 1 = 7'])
end