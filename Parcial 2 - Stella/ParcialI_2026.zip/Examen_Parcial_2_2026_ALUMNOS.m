
%% PARCIAL II: CONTROL Y SISTEMAS

%% Criterio de evaluaión
% _"Se evaluará la calidad del razonamiento 
% técnico y la justificación de las decisiones de diseño."_
%
% _"Priorizar en el análisis descripciones cuantitativas y objetivas." 
% 
% _"Cuide la presentación, escala, colores, títulos y leyendas de sus gráficos para hacerlos 
% lo más legible posible para la evaluación."_

clear;
clc;
close all;

%% Contexto
% Tenemos un sistema que deberá ser modelado, controlado y analizado. Se trata de un
% portón corredizo movido por un motor con su eje solidario a un mecanismo 
% de piñon y cremallera solidaria al portón que permite que este se
% desplace linealmente al girar el motor. La forma en la que el sistema
% disipa la energía se encuentra experimentalmente. 


%% Objetivo
% Modelar y analizar el sistema. 
clc
close all 

m = 200; %kg
c = 0; % Ns/m estimar c
magnitud_pulso_perturbacion = 100; % N
tiempo_pulso_perturbacion = 50; % s
R = 0.05; % m radio del piñón
tau_maximo_motor = 200; % Nm




%% 1. Modelado del Portón Corredizo
% Modele el portón corredizo. Estimar  el parámetro faltante (c) sabiendo que el portón pasa
% sin fuerzas externas (ni perturbación ni motor) de 1m/s a 0.1m/s en 1s. 
% Luego de obtener las ecuaciones físicas elabore un modelo en SIMULINK.
% Valide el modelo.


% [Ingresa tu modelado aquí]
% a(t) = x_ddot(t), v(t) = x_dot(t), m, c

% c = 

% Se aceptan aproximaciones de c por prueba y error, si cumplen con        
% v(0 s) = 1.0 m/s    ^    v(1 s) = 0.1 m/s
% con un error menor al 5% en términos de velocidad.


%% 2. Integración con el Controlador de velocidad
% Integre su modelo al controlador PID dado y luego analice desempeño
% frente a r(t) como escalón de 1 m/s

% [SIMULINK]


%% 3. Análisis de Perturbaciones
% Modela el ingreso de una perturbación externa tipo pulso de fuerza de 100 N que va en sentido 
% contrario al de la apertura, justo en el instante de transcurridos
% 49 s de iniciada la maniobra. 
%
% Evalúa el rechazo a esta perturbación de forma objetiva proponga una métrica.

% [Ingresa tu análisis de perturbaciones aquí]



%% 4. Rediseño del Controlador (Sintonía)
% Modifica la sintonía del control cumpliendo con los siguientes compromisos:
% 1. Hacer que el portón abra más rápido ante un escalón en la referencia de velocidad.
% 2. Que la respuesta ante la perturbación se mantenga idéntica a la del punto anterior.

% Copia y pega los bloques del sistema completo, de manera de ver el modelo
% antes y después de rediseñar el controlador, con idénticas r(t) y d(t).

% [SIMULINK]


%% 5. Análisis del Actuador
% A partir de la nueva acción de control (torque del motor con el controlador rediseñado), 
% determina si esto requiere el reemplazo del motor por uno de mayor capacidad.

% [Ingresa tu análisis del actuador aquí]
